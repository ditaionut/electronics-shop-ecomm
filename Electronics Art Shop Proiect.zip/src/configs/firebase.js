// const firebaseConfig = {
//     apiKey: "AIzaSyCcbZMkwd4ZV_1DiH0R3TZFCg9GKaIMeoM",
//     authDomain: "react-sirluggia-shop.firebaseapp.com",
//     databaseURL: "https://react-sirluggia-shop.firebaseio.com",
//     projectId: "react-sirluggia-shop",
//     storageBucket: "react-sirluggia-shop.appspot.com",
//     messagingSenderId: "184253035461",
//     appId: "1:184253035461:web:20fe5c173c7675c74c51ac"
// };

// export default firebaseConfig;

const firebaseConfig = {
    apiKey: "AIzaSyCfniSNFYKbdEB69s7X6CbswduCZTW6sdk",
    authDomain: "online-shop-ad0e0.firebaseapp.com",
    projectId: "online-shop-ad0e0",
    storageBucket: "online-shop-ad0e0.appspot.com",
    messagingSenderId: "124405332448",
    appId: "1:124405332448:web:19f989f5a38962ad0e1385"
  };
    
    export default firebaseConfig;