import React from 'react';
import Layout from "../components/layout_footer_header/Layout"

function About() {
    return(
        <div>
            <Layout>
                <h1>More info in footer</h1>
            </Layout>
        </div>
    );
}

export default About;